export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["favicon.png"]),
	mimeTypes: {".png":"image/png"},
	_: {
		client: {start:"_app/immutable/entry/start.FXHGtwV-.js",app:"_app/immutable/entry/app.DCKl5mIj.js",imports:["_app/immutable/entry/start.FXHGtwV-.js","_app/immutable/chunks/qBHCrFCx.js","_app/immutable/chunks/B0u_76HP.js","_app/immutable/chunks/Bq9sBUGr.js","_app/immutable/chunks/CAmFPD6p.js","_app/immutable/entry/app.DCKl5mIj.js","_app/immutable/chunks/B0u_76HP.js","_app/immutable/chunks/DKxBsBKl.js","_app/immutable/chunks/yw3GhXIK.js","_app/immutable/chunks/CO63-Mo-.js","_app/immutable/chunks/Bq9sBUGr.js","_app/immutable/chunks/CbjzggBr.js","_app/immutable/chunks/CAmFPD6p.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js')),
			__memo(() => import('./nodes/3.js'))
		],
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			},
			{
				id: "/callback",
				pattern: /^\/callback\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 3 },
				endpoint: null
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
