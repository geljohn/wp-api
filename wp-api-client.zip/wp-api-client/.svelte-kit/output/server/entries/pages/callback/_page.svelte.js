import { J as bind_props, C as pop, z as push } from "../../../chunks/index.js";
import { e as escape_html } from "../../../chunks/escaping.js";
function _page($$payload, $$props) {
  push();
  let data = $$props["data"];
  if (data?.error) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<h2 style="color: red;">${escape_html(data.error)}</h2>`;
  } else if (data?.saved) {
    $$payload.out += "<!--[1-->";
    $$payload.out += `<h2>Application Password Generated!</h2> <p><strong>App Name:</strong> ${escape_html(data.app_name)}</p> <p><strong>Domain:</strong> ${escape_html(data.domain)}</p> <p><strong>Username:</strong> ${escape_html(data.username)}</p> <p style="color: green;">Saved to Supabase!</p>`;
  } else {
    $$payload.out += "<!--[!-->";
    $$payload.out += `<h2>Waiting for callback...</h2>`;
  }
  $$payload.out += `<!--]-->`;
  bind_props($$props, { data });
  pop();
}
export {
  _page as default
};
