import { createClient } from "@supabase/supabase-js";
const supabaseUrl = "https://btwfjcubcvfmjjitayni.supabase.co";
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJ0d2ZqY3ViY3ZmbWpqaXRheW5pIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc3MzIxNDMsImV4cCI6MjA2MzMwODE0M30.RpgxcBkD6srC1wYLd5X_DSG36ebEqiDRkaQK8jp9ih0";
const supabase = createClient(supabaseUrl, supabaseAnonKey);
const load = async ({ url }) => {
  const domain = url.searchParams.get("site_url");
  const username = url.searchParams.get("user_login");
  const app_password = url.searchParams.get("password");
  const app_name = url.searchParams.get("app_name") ?? "test";
  if (!domain || !username || !app_password) {
    return { error: "Missing required parameters in callback URL." };
  }
  const { error } = await supabase.from("wordpress_apps").insert([
    {
      app_name,
      app_password,
      domain,
      username
    }
  ]);
  if (error) {
    return { error: error.message };
  }
  return {
    saved: true,
    app_name,
    app_password,
    domain,
    username
  };
};
export {
  load
};
