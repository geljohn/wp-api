

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.BQusUTMi.js","_app/immutable/chunks/yw3GhXIK.js","_app/immutable/chunks/B0u_76HP.js","_app/immutable/chunks/C_5GLnAg.js","_app/immutable/chunks/DKxBsBKl.js","_app/immutable/chunks/qBHCrFCx.js","_app/immutable/chunks/Bq9sBUGr.js","_app/immutable/chunks/CAmFPD6p.js"];
export const stylesheets = [];
export const fonts = [];
