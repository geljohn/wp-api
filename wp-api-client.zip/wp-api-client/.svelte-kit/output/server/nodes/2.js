

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.Bdl6McNQ.js","_app/immutable/chunks/yw3GhXIK.js","_app/immutable/chunks/B0u_76HP.js","_app/immutable/chunks/DKxBsBKl.js","_app/immutable/chunks/CO63-Mo-.js","_app/immutable/chunks/Bq9sBUGr.js","_app/immutable/chunks/qBHCrFCx.js","_app/immutable/chunks/CAmFPD6p.js"];
export const stylesheets = [];
export const fonts = [];
