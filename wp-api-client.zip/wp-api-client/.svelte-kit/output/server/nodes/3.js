import * as server from '../entries/pages/callback/_page.server.ts.js';

export const index = 3;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/callback/_page.svelte.js')).default;
export { server };
export const server_id = "src/routes/callback/+page.server.ts";
export const imports = ["_app/immutable/nodes/3.Oz2JHEfP.js","_app/immutable/chunks/yw3GhXIK.js","_app/immutable/chunks/B0u_76HP.js","_app/immutable/chunks/C_5GLnAg.js","_app/immutable/chunks/DKxBsBKl.js","_app/immutable/chunks/CO63-Mo-.js","_app/immutable/chunks/Bq9sBUGr.js","_app/immutable/chunks/CbjzggBr.js"];
export const stylesheets = [];
export const fonts = [];
