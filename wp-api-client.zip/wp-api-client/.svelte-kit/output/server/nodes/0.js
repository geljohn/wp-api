

export const index = 0;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/layout.svelte.js')).default;
export const imports = ["_app/immutable/nodes/0.CelCkdnz.js","_app/immutable/chunks/yw3GhXIK.js","_app/immutable/chunks/B0u_76HP.js"];
export const stylesheets = [];
export const fonts = [];
